const Influx = require('influx');

const influx = new Influx.InfluxDB({
    host: 'localhost',
    database: 'pwr_shed',
    schema: [
      {
        measurement: 'userConsumptionInPowerShed',
        fields: { unitConsumed: Influx.FieldType.INTEGER },
        tags: ['user']
      }
    ]
  });

  influx.getDatabaseNames()
  .then(names => {
    if (!names.includes('pwr_shed')) {
      return influx.createDatabase('pwr_shed');
    }
  });
//    (() => {
//     app.listen(app.get('port'), () => {
//       console.log(`Listening on ${app.get('port')}.`);
//     });
    // writeDataToInflux(100);
// })

module.exports.addUserConsumptionInPowerShed = (data,callback)=>{

    /*

    data = {
        user:"userId <string>",
        consumptions:" units consumed <int> "
    }

    */

    influx.writePoints([
    {
      measurement: 'userConsumptionInPowerShed',
      tags: {
        user:data.user                    //userId form req.body
        
      },
      fields: { unitConsumed: data.consumptions },   // get this value from req.body
    }
  ], {
    database: 'pwr_shed',   // which database is the measurement
    
  }).then(data=>{console.log(data);
  })


}
  